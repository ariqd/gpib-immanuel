<tr>
    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '1'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '1'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '1'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <td colspan="2"></td>

    
    <td colspan="2"></td>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'F', 'seatNumber' => '1'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'F', 'seatNumber' => '2', 'colspan' => '2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'F', 'seatNumber' => '3'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <td colspan="4"></td>

    
    <td colspan="2"></td>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'I', 'seatNumber' => '1', 'colspan' => '2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'I', 'seatNumber' => '2', 'colspan' => '2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</tr>
<?php /**PATH D:\x\htdocs\gpibimmanuel\resources\views/worship/seats/row_1.blade.php ENDPATH**/ ?>