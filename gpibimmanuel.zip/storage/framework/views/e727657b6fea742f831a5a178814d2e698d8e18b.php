<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-3">
        <div class="row">
            <div class="col-12">
                <h3>Pendaftaran Ibadah</h3>
                <hr>
            </div>
        </div>
        <div class="row">
            <form action="<?php echo e(route('worships.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="worship_id" value="<?php echo e($worship_id); ?>">
                <div class="table-responsive">
                    <table class="table table-borderless">
                        <thead>
                            <tr>
                                <th colspan="10">
                                    Lantai 1
                                </th>
                                <th colspan="14">
                                    Lantai 2
                                </th>
                            </tr>
                            <tr>
                                <th colspan="10">
                                    <div style="text-align: center; width: 100%; padding: 25px; border: 1px solid black">
                                        Mimbar
                                    </div>
                                </th>
                                <th colspan="14">
                                    <div style="text-align: center; width: 100%; padding: 25px; border: 1px solid black">
                                        Batas Balkon
                                    </div>
                                </th>
                            </tr>
                            <tr>
                                <th scope="col" colspan="2" class="text-center">A</th>
                                <th scope="col" colspan="2" class="text-center">B</th>
                                <th scope="col" colspan="2" class="text-center">C</th>
                                <th scope="col" colspan="2" class="text-center">D</th>
                                <th scope="col" colspan="2" class="text-center">E</th>
                                <th scope="col" colspan="4" class="text-center">F</th>
                                <th scope="col" colspan="4" class="text-center">G</th>
                                <th scope="col" colspan="2" class="text-center">H</th>
                                <th scope="col" colspan="4" class="text-center">I</th>
                            </tr>
                        </thead>
                        <tbody>
                            

                            <?php echo $__env->make('worship.seats.row_1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('worship.seats.row_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('worship.seats.row_3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('worship.seats.row_4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('worship.seats.row_5', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('worship.seats.row_6', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('worship.seats.row_7', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('worship.seats.row_8', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('worship.seats.row_9', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('worship.seats.row_10', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('worship.seats.row_11', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('worship.seats.row_12', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('worship.seats.row_13', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex flex-row-reverse">
                    <button type="submit" class="btn btn-success">Booking Sekarang <i
                            class="bi bi-arrow-right"></i></button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\x\htdocs\gpibimmanuel\resources\views/worship/show.blade.php ENDPATH**/ ?>