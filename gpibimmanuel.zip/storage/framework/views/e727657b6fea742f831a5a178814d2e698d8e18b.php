<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-3">
        <div class="row">
            <div class="col-12">
                <h3>Pendaftaran Ibadah</h3>
                <hr>
            </div>
        </div>
        <div class="row">
            <form action="<?php echo e(route('worships.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="table-responsive">
                    <table class="table table-borderless">
                        <thead>
                            <tr>
                                <th colspan="10">
                                    Lantai 1
                                </th>
                                <th colspan="14">
                                    Lantai 2
                                </th>
                            </tr>
                            <tr>
                                <th colspan="10">
                                    <div style="text-align: center; width: 100%; padding: 25px; border: 1px solid black">
                                        Mimbar
                                    </div>
                                </th>
                                <th colspan="14">
                                    <div style="text-align: center; width: 100%; padding: 25px; border: 1px solid black">
                                        Batas Balkon
                                    </div>
                                </th>
                            </tr>
                            <tr>
                                <th scope="col" colspan="2" class="text-center">A</th>
                                <th scope="col" colspan="2" class="text-center">B</th>
                                <th scope="col" colspan="2" class="text-center">C</th>
                                <th scope="col" colspan="2" class="text-center">D</th>
                                <th scope="col" colspan="2" class="text-center">E</th>
                                <th scope="col" colspan="4" class="text-center">F</th>
                                <th scope="col" colspan="4" class="text-center">G</th>
                                <th scope="col" colspan="2" class="text-center">H</th>
                                <th scope="col" colspan="4" class="text-center">I</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                function generateSeat($row_number)
                                {
                                    if ($row_number == 1) {
                                        return 'A';
                                    } elseif ($row_number == 2) {
                                        return 'B';
                                    } elseif ($row_number == 3) {
                                        return 'C';
                                    } elseif ($row_number == 4) {
                                        return 'D';
                                    } elseif ($row_number == 5) {
                                        return 'E';
                                    } elseif ($row_number == 6) {
                                        return 'F';
                                    } elseif ($row_number == 7) {
                                        return 'G';
                                    } elseif ($row_number == 8) {
                                        return 'H';
                                    } elseif ($row_number == 9) {
                                        return 'I';
                                    }
                                }
                            ?>
                            <tr>
                                
                                <?php for($x = 1; $x <= 9; $x++): ?>
                                    <?php if($x == 4 || $x == 5 || $x == 8): ?>
                                        <td colspan="2"></td>
                                    <?php elseif($x == 7): ?>
                                        <td colspan="4"></td>
                                    <?php elseif($x == 6): ?>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off" name="input[]"
                                                    value="seat<?php echo e(generateSeat($x)); ?>1" id="seat<?php echo e(generateSeat($x)); ?>1">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>1">
                                                    1
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off" name="input[]"
                                                    value="seat<?php echo e(generateSeat($x)); ?>2" id="seat<?php echo e(generateSeat($x)); ?>2">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>2">
                                                    2
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off" name="input[]"
                                                    value="seat<?php echo e(generateSeat($x)); ?>3" id="seat<?php echo e(generateSeat($x)); ?>3">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>3">
                                                    3
                                                </label>
                                            </div>
                                        </td>
                                    <?php elseif($x == 9): ?>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off" name="input[]"
                                                    value="seat<?php echo e(generateSeat($x)); ?>1" id="seat<?php echo e(generateSeat($x)); ?>1">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>1">
                                                    1
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off" name="input[]"
                                                    value="seat<?php echo e(generateSeat($x)); ?>2" id="seat<?php echo e(generateSeat($x)); ?>2">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>2">
                                                    2
                                                </label>
                                            </div>
                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off" name="input[]"
                                                    value="seat<?php echo e(generateSeat($x)); ?>1"
                                                    id="seat<?php echo e(generateSeat($x)); ?>1">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>1">
                                                    1
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>2"
                                                    id="seat<?php echo e(generateSeat($x)); ?>2">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>2">
                                                    2
                                                </label>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                
                                <?php for($x = 1; $x <= 9; $x++): ?>
                                    <?php if($x == 2): ?>
                                        <td colspan="2" class="align-middle text-center text-danger">
                                            Camera 2
                                        </td>
                                    <?php elseif($x == 6): ?>
                                        
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>4"
                                                    id="seat<?php echo e(generateSeat($x)); ?>4">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>4">
                                                    4
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>5"
                                                    id="seat<?php echo e(generateSeat($x)); ?>5">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>5">
                                                    5
                                                </label>
                                            </div>
                                        </td>
                                    <?php elseif($x == 7): ?>
                                        
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>3"
                                                    id="seat<?php echo e(generateSeat($x)); ?>3">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>3">
                                                    3
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>4"
                                                    id="seat<?php echo e(generateSeat($x)); ?>4">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>4">
                                                    4
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>5"
                                                    id="seat<?php echo e(generateSeat($x)); ?>5">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>5">
                                                    5
                                                </label>
                                            </div>
                                        </td>
                                    <?php elseif($x == 9): ?>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>3"
                                                    id="seat<?php echo e(generateSeat($x)); ?>3">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>3">
                                                    3
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>4"
                                                    id="seat<?php echo e(generateSeat($x)); ?>4">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>4">
                                                    4
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>5"
                                                    id="seat<?php echo e(generateSeat($x)); ?>5">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>5">
                                                    5
                                                </label>
                                            </div>
                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>3"
                                                    id="seat<?php echo e(generateSeat($x)); ?>3">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>3">
                                                    3
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>4"
                                                    id="seat<?php echo e(generateSeat($x)); ?>4">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>4">
                                                    4
                                                </label>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                
                                <?php for($x = 1; $x <= 9; $x++): ?>
                                    <?php if($x == 6): ?>
                                        
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>6"
                                                    id="seat<?php echo e(generateSeat($x)); ?>6">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>6">
                                                    6
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>7"
                                                    id="seat<?php echo e(generateSeat($x)); ?>7">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>7">
                                                    7
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>8"
                                                    id="seat<?php echo e(generateSeat($x)); ?>8">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>8">
                                                    8
                                                </label>
                                            </div>
                                        </td>
                                    <?php elseif($x == 7): ?>
                                        
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>6"
                                                    id="seat<?php echo e(generateSeat($x)); ?>6">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>6">
                                                    6
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>7"
                                                    id="seat<?php echo e(generateSeat($x)); ?>7">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>7">
                                                    7
                                                </label>
                                            </div>
                                        </td>
                                    <?php elseif($x == 9): ?>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>6"
                                                    id="seat<?php echo e(generateSeat($x)); ?>6">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>6">
                                                    6
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>7"
                                                    id="seat<?php echo e(generateSeat($x)); ?>7">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>7">
                                                    7
                                                </label>
                                            </div>
                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>5"
                                                    id="seat<?php echo e(generateSeat($x)); ?>5">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>5">
                                                    5
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>6"
                                                    id="seat<?php echo e(generateSeat($x)); ?>6">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>6">
                                                    6
                                                </label>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                
                                <?php for($x = 1; $x <= 9; $x++): ?>
                                    <?php if($x == 6): ?>
                                        
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>9"
                                                    id="seat<?php echo e(generateSeat($x)); ?>9">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>9">
                                                    9
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>10"
                                                    id="seat<?php echo e(generateSeat($x)); ?>10">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>10">
                                                    10
                                                </label>
                                            </div>
                                        </td>
                                    <?php elseif($x == 7): ?>
                                        
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>8"
                                                    id="seat<?php echo e(generateSeat($x)); ?>8">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>8">
                                                    8
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>9"
                                                    id="seat<?php echo e(generateSeat($x)); ?>9">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>9">
                                                    9
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>10"
                                                    id="seat<?php echo e(generateSeat($x)); ?>10">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>10">
                                                    10
                                                </label>
                                            </div>
                                        </td>
                                    <?php elseif($x == 9): ?>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>8"
                                                    id="seat<?php echo e(generateSeat($x)); ?>8">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>8">
                                                    8
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>9"
                                                    id="seat<?php echo e(generateSeat($x)); ?>9">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>9">
                                                    9
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>10"
                                                    id="seat<?php echo e(generateSeat($x)); ?>10">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>10">
                                                    10
                                                </label>
                                            </div>
                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>7"
                                                    id="seat<?php echo e(generateSeat($x)); ?>7">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>7">
                                                    7
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>8"
                                                    id="seat<?php echo e(generateSeat($x)); ?>8">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>8">
                                                    8
                                                </label>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                
                                <?php for($x = 1; $x <= 9; $x++): ?>
                                    <?php if($x == 6): ?>
                                        
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>11"
                                                    id="seat<?php echo e(generateSeat($x)); ?>11">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>11">
                                                    11
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>12"
                                                    id="seat<?php echo e(generateSeat($x)); ?>12">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>12">
                                                    12
                                                </label>
                                            </div>
                                        </td>
                                    <?php elseif($x == 7): ?>
                                        
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>11"
                                                    id="seat<?php echo e(generateSeat($x)); ?>11">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>11">
                                                    11
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>12"
                                                    id="seat<?php echo e(generateSeat($x)); ?>12">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>12">
                                                    12
                                                </label>
                                            </div>
                                        </td>
                                    <?php elseif($x == 9): ?>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>11"
                                                    id="seat<?php echo e(generateSeat($x)); ?>11">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>11">
                                                    11
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>12"
                                                    id="seat<?php echo e(generateSeat($x)); ?>12">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>12">
                                                    12
                                                </label>
                                            </div>
                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>9"
                                                    id="seat<?php echo e(generateSeat($x)); ?>9">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>9">
                                                    9
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>10"
                                                    id="seat<?php echo e(generateSeat($x)); ?>10">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>10">
                                                    10
                                                </label>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                
                                <?php for($x = 1; $x <= 9; $x++): ?>
                                    <?php if($x == 6 || $x == 9): ?>
                                        
                                        <td colspan="4"></td>
                                    <?php elseif($x == 7): ?>
                                        
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>13"
                                                    id="seat<?php echo e(generateSeat($x)); ?>13">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>13">
                                                    13
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>14"
                                                    id="seat<?php echo e(generateSeat($x)); ?>14">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>14">
                                                    14
                                                </label>
                                            </div>
                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>11"
                                                    id="seat<?php echo e(generateSeat($x)); ?>11">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>11">
                                                    11
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>12"
                                                    id="seat<?php echo e(generateSeat($x)); ?>12">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>12">
                                                    12
                                                </label>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                
                                <?php for($x = 1; $x <= 9; $x++): ?>
                                    <?php if($x == 6 || $x == 8 || $x == 9): ?>
                                        
                                        <td colspan="<?php echo e($x == 6 || $x == 9 ? 4 : 2); ?>"></td>
                                    <?php elseif($x == 7): ?>
                                        
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>15"
                                                    id="seat<?php echo e(generateSeat($x)); ?>15">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>15">
                                                    15
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>16"
                                                    id="seat<?php echo e(generateSeat($x)); ?>16">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>16">
                                                    16
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>17"
                                                    id="seat<?php echo e(generateSeat($x)); ?>17">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>17">
                                                    17
                                                </label>
                                            </div>
                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>13"
                                                    id="seat<?php echo e(generateSeat($x)); ?>13">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>13">
                                                    13
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>14"
                                                    id="seat<?php echo e(generateSeat($x)); ?>14">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>14">
                                                    14
                                                </label>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                
                                <?php for($x = 1; $x <= 9; $x++): ?>
                                    <?php if($x == 6 || $x == 8 || $x == 9): ?>
                                        
                                        <td colspan="<?php echo e($x == 6 || $x == 9 ? 4 : 2); ?>"></td>
                                    <?php elseif($x == 7): ?>
                                        
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>18"
                                                    id="seat<?php echo e(generateSeat($x)); ?>18">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>18">
                                                    18
                                                </label>
                                            </div>
                                        </td>
                                        <td colspan="2">
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>19"
                                                    id="seat<?php echo e(generateSeat($x)); ?>19">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>19">
                                                    19
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>20"
                                                    id="seat<?php echo e(generateSeat($x)); ?>20">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>20">
                                                    20
                                                </label>
                                            </div>
                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>15"
                                                    id="seat<?php echo e(generateSeat($x)); ?>15">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>15">
                                                    15
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>16"
                                                    id="seat<?php echo e(generateSeat($x)); ?>16">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>16">
                                                    16
                                                </label>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                
                                <?php for($x = 1; $x <= 9; $x++): ?>
                                    <?php if($x == 3): ?>
                                        <td colspan="2" class="align-middle text-center text-danger">
                                            Camera 1
                                        </td>
                                    <?php elseif($x == 6 || $x == 7 || $x == 8 || $x == 9): ?>
                                        
                                        <td colspan="<?php echo e($x == 6 || $x == 7 || $x == 9 ? 4 : 2); ?>"></td>
                                    <?php else: ?>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>17"
                                                    id="seat<?php echo e(generateSeat($x)); ?>17">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>17">
                                                    17
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>18"
                                                    id="seat<?php echo e(generateSeat($x)); ?>18">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>18">
                                                    18
                                                </label>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <?php for($x = 1; $x <= 9; $x++): ?>
                                    <?php if($x == 6 || $x == 7 || $x == 8 || $x == 9): ?>
                                        
                                        <td colspan="<?php echo e($x == 6 || $x == 7 || $x == 9 ? 4 : 2); ?>"></td>
                                    <?php else: ?>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>19"
                                                    id="seat<?php echo e(generateSeat($x)); ?>19">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>19">
                                                    19
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>20"
                                                    id="seat<?php echo e(generateSeat($x)); ?>20">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>20">
                                                    20
                                                </label>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <?php for($x = 1; $x <= 9; $x++): ?>
                                    <?php if($x == 6 || $x == 7 || $x == 8 || $x == 9): ?>
                                        
                                        <td colspan="<?php echo e($x == 6 || $x == 7 || $x == 9 ? 4 : 2); ?>"></td>
                                    <?php else: ?>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>21"
                                                    id="seat<?php echo e(generateSeat($x)); ?>21">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>21">
                                                    21
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>22"
                                                    id="seat<?php echo e(generateSeat($x)); ?>22">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>22">
                                                    22
                                                </label>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <?php for($x = 1; $x <= 9; $x++): ?>
                                    <?php if($x == 6 || $x == 7 || $x == 8 || $x == 9): ?>
                                        
                                        <td colspan="<?php echo e($x == 6 || $x == 7 || $x == 9 ? 4 : 2); ?>"></td>
                                    <?php else: ?>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>23"
                                                    id="seat<?php echo e(generateSeat($x)); ?>23">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>23">
                                                    23
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>24"
                                                    id="seat<?php echo e(generateSeat($x)); ?>24">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>24">
                                                    24
                                                </label>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <?php for($x = 1; $x <= 9; $x++): ?>
                                    <?php if($x == 6 || $x == 7 || $x == 8 || $x == 9): ?>
                                        
                                        <td colspan="<?php echo e($x == 6 || $x == 7 || $x == 9 ? 4 : 2); ?>"></td>
                                    <?php else: ?>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>25"
                                                    id="seat<?php echo e(generateSeat($x)); ?>25">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>25">
                                                    25
                                                </label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
                                                <input type="checkbox" class="btn-check" autocomplete="off"
                                                    name="input[]" value="seat<?php echo e(generateSeat($x)); ?>26"
                                                    id="seat<?php echo e(generateSeat($x)); ?>26">
                                                <label class="btn btn-sm btn-outline-success"
                                                    for="seat<?php echo e(generateSeat($x)); ?>26">
                                                    26
                                                </label>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <button type="submit" class="btn btn-primary">Book Now</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\x\htdocs\gpibimmanuel\resources\views/worship/show.blade.php ENDPATH**/ ?>