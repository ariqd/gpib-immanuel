<?php $__env->startSection('profile_page'); ?>
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between">
                <h3>Tiket Saya</h3>
            </div>
            <hr>
        </div>
    </div>

    <div class="row">
        <?php $__currentLoopData = $worships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php ($worship_date = \Carbon\Carbon::parse($worship->worship_date)); ?>
            <?php ($seats = $worship->bookings->pluck('booking_seat')); ?>
            <div class="col-6 mt-3">
                <div class="card">
                    <img src="https://via.placeholder.com/300x150" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($worship->worship_name); ?></h5>
                        <p class="card-text">Tanggal: <?php echo e($worship_date->isoFormat('dddd, D MMMM Y')); ?> <br> Waktu:
                            <?php echo e(date('G:i', strtotime($worship->worship_time))); ?>

                        </p>
                        <h5 class="card-title">Kursi</h5>
                        <h5><?php echo e($seats->join(',')); ?></h5>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\x\htdocs\gpibimmanuel\resources\views/booking/index.blade.php ENDPATH**/ ?>