<?php $__env->startSection('content'); ?>
    <div class="container py-3">
        <div class="row">
            <div class="col-3">
                <div class="list-group">
                    <a href="<?php echo e(route('profile.bookings.index')); ?>"
                        class="list-group-item list-group-item-action <?php echo e(request()->is('profile/bookings*') ? 'active' : ''); ?>"
                        aria-current="true">
                        Tiket Saya
                    </a>
                    <a href="#"
                        class="list-group-item list-group-item-action <?php echo e(request()->is('profile/bio*') ? 'active' : ''); ?>">Biodata</a>
                </div>
            </div>
            <div class="col-9">
                <?php echo $__env->yieldContent('profile_page'); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\x\htdocs\gpibimmanuel\resources\views/layouts/profile.blade.php ENDPATH**/ ?>