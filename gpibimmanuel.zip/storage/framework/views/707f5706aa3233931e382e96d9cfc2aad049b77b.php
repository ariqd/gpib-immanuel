<tr>
    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '5'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '6'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '3'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '4'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '5'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '6'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '3'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '4'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '3'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '4'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'F', 'seatNumber' => '6'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'F', 'seatNumber' => '7', 'colspan' => '2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'F', 'seatNumber' => '8'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '4', 'colspan' => '2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '5', 'colspan' => '2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'H', 'seatNumber' => '3'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'H', 'seatNumber' => '4'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'I', 'seatNumber' => '6', 'colspan' => '2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'I', 'seatNumber' => '7', 'colspan' => '2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<tr>
<?php /**PATH D:\x\htdocs\gpibimmanuel\resources\views/worship/seats/row_3.blade.php ENDPATH**/ ?>