<tr>
    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '11'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '12'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '9'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '10'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '11'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '12'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '9'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '10'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '9'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '10'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <td colspan="4"></td>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '11', 'colspan' => '2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '12', 'colspan' => '2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'H', 'seatNumber' => '9'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'H', 'seatNumber' => '10'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
<tr>
<?php /**PATH D:\x\htdocs\gpibimmanuel\resources\views/worship/seats/row_6.blade.php ENDPATH**/ ?>