<?php
    $seat = $seatLetter . $seatNumber;
?>

<td colspan="<?php echo e(@$colspan); ?>">
    <div class="d-grid gap-2 col-6 mx-auto" style="width: 50px">
        <input type="checkbox" class="btn-check" autocomplete="off" name="input[]"
            <?php echo e(in_array($seat, $booked_seats) ? 'checked disabled' : ''); ?> value="<?php echo e($seat); ?>" id="<?php echo e($seat); ?>">
        <label class="btn btn-sm btn-outline-success" for="<?php echo e($seat); ?>">
            <?php echo e($seatNumber); ?>

        </label>
    </div>
</td>
<?php /**PATH D:\x\htdocs\gpibimmanuel\resources\views/worship/seats/seat/component.blade.php ENDPATH**/ ?>