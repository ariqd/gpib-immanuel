<tr>
    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '25'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '26'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '23'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '24'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '25'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '26'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '23'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '24'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '23'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '24'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

    

    

    
<tr>
<?php /**PATH D:\x\htdocs\gpibimmanuel\resources\views/worship/seats/row_13.blade.php ENDPATH**/ ?>