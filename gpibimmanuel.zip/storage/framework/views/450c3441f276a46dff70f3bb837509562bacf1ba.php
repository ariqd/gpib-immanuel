<tr>
    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '15'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '16'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '13'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '14'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '15'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '16'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '13'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '14'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '13'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '14'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

    

    

    
<tr>
<?php /**PATH D:\x\htdocs\gpibimmanuel\resources\views/worship/seats/row_8.blade.php ENDPATH**/ ?>