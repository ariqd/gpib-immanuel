<footer class="mt-auto py-3" style="background: #34647A; color: white">
    <div class="container">
        <div class="row">
            <div class="col-6">
                <h4>Kontak Kami</h4>
                <div class="row mt-3">
                    <div class="col-12 d-flex">
                        <i class="bi bi-envelope-fill"></i>
                        <p class="mx-3">gpibimmanuelpekanbaru@gmail.com</p>
                    </div>
                    <div class="col-12 d-flex">
                        <i class="bi bi-telephone-fill"></i>
                        <p class="mx-3">(0888) 8888888</p>
                    </div>
                    <div class="col-12 d-flex">
                        <i class="bi bi-clock-fill"></i>
                        <p class="mx-3">Selasa - Sabtu: 08:30 - 16:00</p>
                    </div>
                    <div class="col-12 d-flex">
                        <i class="bi bi-geo-alt-fill"></i>
                        <p class="mx-3">Jl. Sumatera no. 21-23, Simpang Empat, Kec. Pekanbaru Kota, Kota Pekanbaru, Riau</p>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <h4>Map GPIB Immanuel Pekanbaru</h4>
                <div class="row mt-3">
                    <div class="col-12 d-flex">
                        <div id="map"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\x\htdocs\gpibimmanuel\resources\views/components/footer.blade.php ENDPATH**/ ?>