<?php $__env->startSection('content'); ?>
    <div class="container py-3">
        <div class="row">
            <div class="col-12">
                <h3>Pendaftaran Ibadah</h3>
                <hr>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $worships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($worship_date = \Carbon\Carbon::parse($worship->worship_date)); ?>
                <div class="col-6 mt-3">
                    <div class="card">
                        <img src="https://via.placeholder.com/300x150" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($worship->worship_name); ?></h5>
                            <p class="card-text">Tanggal: <?php echo e($worship_date->isoFormat('dddd, D MMMM Y')); ?> <br> Waktu:
                                <?php echo e(date('G:i', strtotime($worship->worship_time))); ?>

                            </p>
                            <div class="d-grid">
                                <?php if($worship_date->isPast()): ?>
                                    <button type="button" disabled
                                        class="btn btn-success btn-block stretched-link btn-disabled">Daftar</button>
                                <?php else: ?>
                                    <a href="<?php echo e(route('worships.show', $worship->id)); ?>"
                                        class="btn btn-success btn-block stretched-link">Daftar</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\x\htdocs\gpibimmanuel\resources\views/worship/index.blade.php ENDPATH**/ ?>