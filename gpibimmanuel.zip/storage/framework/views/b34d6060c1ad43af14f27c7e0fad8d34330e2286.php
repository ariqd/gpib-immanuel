<nav class="navbar navbar-dark navbar-expand-lg" style="background: #34647A">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">GPIB Immanuel Pekanbaru</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('/') ? 'active' : ''); ?>" aria-current="page"
                        href="<?php echo e(url('/')); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('worships*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('worships.index')); ?>">Pendaftaran Ibadah</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->is('news*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('news.index')); ?>">Tata Ibadah & Warta</a>
                </li>
            </ul>
            <div class="d-flex" role="search">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="#">
                                <i class="bi-person"></i> Hello, <?php echo e(auth()->user()->name); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>

                                <a class="nav-link" aria-current="page" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                                this.closest('form').submit();">
                                    <?php echo e(__('Log Out')); ?>

                                </a>
                            </form>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="<?php echo e(route('login')); ?>">
                                Login
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="<?php echo e(route('register')); ?>">
                                Register
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH D:\x\htdocs\gpibimmanuel\resources\views/components/navbar.blade.php ENDPATH**/ ?>