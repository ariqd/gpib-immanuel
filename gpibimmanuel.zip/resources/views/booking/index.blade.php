@extends('layouts.profile')

@section('profile_page')
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between">
                <h3>Tiket Saya</h3>
            </div>
            <hr>
        </div>
    </div>

    <div class="row">
        @foreach ($worships as $worship)
            @php($worship_date = \Carbon\Carbon::parse($worship->worship_date))
            @php($seats = $worship->bookings->pluck('booking_seat'))
            <div class="col-6 mt-3">
                <div class="card">
                    <img src="https://via.placeholder.com/300x150" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">{{ $worship->worship_name }}</h5>
                        <p class="card-text">Tanggal: {{ $worship_date->isoFormat('dddd, D MMMM Y') }} <br> Waktu:
                            {{ date('G:i', strtotime($worship->worship_time)) }}
                        </p>
                        <h5 class="card-title">Kursi</h5>
                        <h5>{{ $seats->join(',') }}</h5>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endsection
