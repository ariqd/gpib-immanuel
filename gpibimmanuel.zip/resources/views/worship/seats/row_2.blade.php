<tr>
    {{-- A --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '3'])
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '4'])

    {{-- B --}}
    <td colspan="2" class="align-middle text-center text-danger">
        Camera 2
    </td>

    {{-- C --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '3'])
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '4'])

    {{-- D --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '1'])
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '2'])

    {{-- E --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '1'])
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '2'])

    {{-- F --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'F', 'seatNumber' => '4', 'colspan' => '2'])
    @include('worship.seats.seat.component', ['seatLetter' => 'F', 'seatNumber' => '5', 'colspan' => '2'])

    {{-- G --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '1'])
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '2', 'colspan' => '2'])
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '3'])

    {{-- H --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'H', 'seatNumber' => '1'])
    @include('worship.seats.seat.component', ['seatLetter' => 'H', 'seatNumber' => '2'])

    {{-- I --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'I', 'seatNumber' => '3'])
    @include('worship.seats.seat.component', ['seatLetter' => 'I', 'seatNumber' => '4', 'colspan' => '2'])
    @include('worship.seats.seat.component', ['seatLetter' => 'I', 'seatNumber' => '5'])
<tr>
