<tr>
    {{-- A --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '13'])
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '14'])

    {{-- B --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '11'])
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '12'])

    {{-- C --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '13'])
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '14'])

    {{-- D --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '11'])
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '12'])

    {{-- E --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '11'])
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '12'])

    {{-- F --}}
    <td colspan="4"></td>

    {{-- G --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '13'])
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '14', 'colspan' => '2'])
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '15'])

    {{-- H --}}

    {{-- I --}}
<tr>
