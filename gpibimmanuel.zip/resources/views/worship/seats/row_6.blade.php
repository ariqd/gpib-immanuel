<tr>
    {{-- A --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '11'])
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '12'])

    {{-- B --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '9'])
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '10'])

    {{-- C --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '11'])
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '12'])

    {{-- D --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '9'])
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '10'])

    {{-- E --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '9'])
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '10'])

    {{-- F --}}
    <td colspan="4"></td>

    {{-- G --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '11', 'colspan' => '2'])
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '12', 'colspan' => '2'])

    {{-- H --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'H', 'seatNumber' => '9'])
    @include('worship.seats.seat.component', ['seatLetter' => 'H', 'seatNumber' => '10'])

    {{-- I --}}
<tr>
