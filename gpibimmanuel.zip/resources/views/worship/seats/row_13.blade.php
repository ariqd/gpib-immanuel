<tr>
    {{-- A --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '25'])
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '26'])

    {{-- B --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '23'])
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '24'])

    {{-- C --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '25'])
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '26'])

    {{-- D --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '23'])
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '24'])

    {{-- E --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '23'])
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '24'])

    {{-- F --}}

    {{-- G --}}

    {{-- H --}}

    {{-- I --}}
<tr>
