<tr>
    {{-- A --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '23'])
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '24'])

    {{-- B --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '21'])
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '22'])

    {{-- C --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '23'])
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '24'])

    {{-- D --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '21'])
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '22'])

    {{-- E --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '21'])
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '22'])

    {{-- F --}}

    {{-- G --}}

    {{-- H --}}

    {{-- I --}}
<tr>
