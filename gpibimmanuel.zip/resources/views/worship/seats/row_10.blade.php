<tr>
    {{-- A --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '19'])
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '20'])

    {{-- B --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '17'])
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '18'])

    {{-- C --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '19'])
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '20'])

    {{-- D --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '17'])
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '18'])

    {{-- E --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '17'])
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '8'])

    {{-- F --}}

    {{-- G --}}

    {{-- H --}}

    {{-- I --}}
<tr>
