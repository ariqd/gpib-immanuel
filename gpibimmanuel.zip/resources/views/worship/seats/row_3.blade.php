<tr>
    {{-- A --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '5'])
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '6'])

    {{-- B --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '3'])
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '4'])

    {{-- C --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '5'])
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '6'])

    {{-- D --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '3'])
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '4'])

    {{-- E --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '3'])
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '4'])

    {{-- F --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'F', 'seatNumber' => '6'])
    @include('worship.seats.seat.component', ['seatLetter' => 'F', 'seatNumber' => '7', 'colspan' => '2'])
    @include('worship.seats.seat.component', ['seatLetter' => 'F', 'seatNumber' => '8'])

    {{-- G --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '4', 'colspan' => '2'])
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '5', 'colspan' => '2'])

    {{-- H --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'H', 'seatNumber' => '3'])
    @include('worship.seats.seat.component', ['seatLetter' => 'H', 'seatNumber' => '4'])

    {{-- I --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'I', 'seatNumber' => '6', 'colspan' => '2'])
    @include('worship.seats.seat.component', ['seatLetter' => 'I', 'seatNumber' => '7', 'colspan' => '2'])
<tr>
