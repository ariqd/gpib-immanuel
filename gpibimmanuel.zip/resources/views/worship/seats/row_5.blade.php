<tr>
    {{-- A --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '9'])
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '10'])

    {{-- B --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '7'])
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '8'])

    {{-- C --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '9'])
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '10'])

    {{-- D --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '7'])
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '8'])

    {{-- E --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '7'])
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '8'])

    {{-- F --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'F', 'seatNumber' => '11', 'colspan' => '2'])
    @include('worship.seats.seat.component', ['seatLetter' => 'F', 'seatNumber' => '12', 'colspan' => '2'])

    {{-- G --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '9', 'colspan' => '2'])
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '10', 'colspan' => '2'])

    {{-- H --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'H', 'seatNumber' => '7'])
    @include('worship.seats.seat.component', ['seatLetter' => 'H', 'seatNumber' => '8'])

    {{-- I --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '11', 'colspan' => '2'])
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '12', 'colspan' => '2'])
<tr>
