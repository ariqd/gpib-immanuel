<tr>
    {{-- A --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '15'])
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '16'])

    {{-- B --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '13'])
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '14'])

    {{-- C --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '15'])
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '16'])

    {{-- D --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '13'])
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '14'])

    {{-- E --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '13'])
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '14'])

    {{-- F --}}

    {{-- G --}}

    {{-- H --}}

    {{-- I --}}
<tr>
