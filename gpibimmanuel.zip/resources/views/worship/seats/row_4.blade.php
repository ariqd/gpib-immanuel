<tr>
    {{-- A --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '7'])
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '8'])

    {{-- B --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '5'])
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '6'])

    {{-- C --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '7'])
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '8'])

    {{-- D --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '5'])
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '6'])

    {{-- E --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '5'])
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '6'])

    {{-- F --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'F', 'seatNumber' => '9', 'colspan' => '2'])
    @include('worship.seats.seat.component', ['seatLetter' => 'F', 'seatNumber' => '10', 'colspan' => '2'])

    {{-- G --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '6'])
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '7', 'colspan' => '2'])
    @include('worship.seats.seat.component', ['seatLetter' => 'G', 'seatNumber' => '8'])

    {{-- H --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'H', 'seatNumber' => '5'])
    @include('worship.seats.seat.component', ['seatLetter' => 'H', 'seatNumber' => '6'])

    {{-- I --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'I', 'seatNumber' => '8'])
    @include('worship.seats.seat.component', ['seatLetter' => 'I', 'seatNumber' => '9', 'colspan' => '2'])
    @include('worship.seats.seat.component', ['seatLetter' => 'I', 'seatNumber' => '10'])
<tr>
