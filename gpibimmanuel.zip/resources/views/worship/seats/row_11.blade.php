<tr>
    {{-- A --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '21'])
    @include('worship.seats.seat.component', ['seatLetter' => 'A', 'seatNumber' => '22'])

    {{-- B --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '19'])
    @include('worship.seats.seat.component', ['seatLetter' => 'B', 'seatNumber' => '20'])

    {{-- C --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '21'])
    @include('worship.seats.seat.component', ['seatLetter' => 'C', 'seatNumber' => '22'])

    {{-- D --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '19'])
    @include('worship.seats.seat.component', ['seatLetter' => 'D', 'seatNumber' => '20'])

    {{-- E --}}
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '19'])
    @include('worship.seats.seat.component', ['seatLetter' => 'E', 'seatNumber' => '20'])

    {{-- F --}}

    {{-- G --}}

    {{-- H --}}

    {{-- I --}}
<tr>
