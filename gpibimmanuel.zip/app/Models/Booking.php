<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    use HasFactory;

    protected $fillable = [
        'worship_id',
        'booking_seat',
        'user_id',
    ];

    public function worship()
    {
        return $this->belongsTo(Worship::class);
    }
}
